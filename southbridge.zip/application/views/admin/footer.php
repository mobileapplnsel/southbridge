<footer class="footer text-center">
	Copyright &copy; <?php echo (date('Y')>2022)?('2021 - '.date('Y')):'2022'; ?> <a href="javascript:void(0)"> <?php echo comp_name; ?> </a> | All Rights Reserved.
</footer>
